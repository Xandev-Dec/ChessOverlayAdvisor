package com.chess.overlayadvisor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.ServiceInfo
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "RESULT_CODE"
        const val EXTRA_RESULT_DATA = "DATA"
        private const val CHANNEL_ID = "chess_overlay_channel"
    }

    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var guide: BoardGuideView? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            if (panel == null) showOverlay()
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Chess Overlay", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }.setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Chess Overlay aktif")
            .setContentText("Panel overlay sedang berjalan")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(41, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(41, notification)
        }
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun showOverlay() {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels.toFloat()
        val density = metrics.density
        val boardSize = (width - 32f * density).coerceAtLeast(240f * density)
        val top = (metrics.heightPixels - boardSize) / 2f

        guide = BoardGuideView(this).apply {
            boardRect.set(16f * density, top, 16f * density + boardSize, top + boardSize)
            visibility = android.view.View.GONE
        }
        val guideParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(guide, guideParams)

        val label = TextView(this).apply {
            text = "CHESS OVERLAY"
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(8, 8, 8, 8)
        }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xEE18212B.toInt())
            setPadding(6, 4, 6, 4)
            addView(label)
        }

        controls.addView(makeButton("Grid") {
            val v = guide ?: return@makeButton
            v.visibility = if (v.visibility == android.view.View.VISIBLE)
                android.view.View.GONE else android.view.View.VISIBLE
            v.invalidate()
        })
        controls.addView(makeButton("−") { guide?.boardRect?.inset(-12f, -12f); guide?.invalidate() })
        controls.addView(makeButton("+") { guide?.boardRect?.inset(12f, 12f); guide?.invalidate() })
        controls.addView(makeButton("X") { stopSelf() })

        panel = controls
        val panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (72f * density).toInt()
        }
        wm.addView(controls, panelParams)
    }

    private fun makeButton(title: String, action: () -> Unit) = Button(this).apply {
        text = title
        textSize = 11f
        minWidth = 0
        minimumWidth = 0
        setPadding(8, 0, 8, 0)
        setOnClickListener { action() }
    }

    override fun onDestroy() {
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { guide?.let { wm.removeView(it) } } catch (_: Exception) {}
        panel = null
        guide = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
