package com.chess.overlayadvisor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        root.addView(TextView(this).apply {
            text = "Chess Overlay"
            textSize = 26f
            setTextColor(0xFF17212B.toInt())
        })
        root.addView(TextView(this).apply {
            text = "1. Izinkan tampil di atas aplikasi lain.\n2. Kembali ke aplikasi ini.\n3. Tekan Mulai Overlay.\n4. Panel melayang akan muncul. Tidak perlu izin rekam layar untuk menampilkan panel."
            textSize = 16f
            setTextColor(0xFF34495E.toInt())
            setPadding(0, 24, 0, 32)
        })
        root.addView(Button(this).apply {
            text = "Mulai Overlay"
            setOnClickListener { beginOverlay() }
        })
        root.addView(Button(this).apply {
            text = "Hentikan Overlay"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
                Toast.makeText(this@MainActivity, "Overlay dihentikan.", Toast.LENGTH_SHORT).show()
            }
        })
        setContentView(root)
    }

    private fun beginOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            Toast.makeText(this, "Aktifkan izin, kembali ke aplikasi, lalu tekan Mulai Overlay lagi.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Panel overlay sedang dimulai.", Toast.LENGTH_SHORT).show()
            moveTaskToBack(true)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal memulai overlay: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
